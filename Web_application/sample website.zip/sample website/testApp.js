let express = require('express');
let cors = require('cors');

let app = express();


app.use(
    cors({
        origin : '*',
        methods : ['GET', 'POST', 'PUT', 'DELETE'],
        allowHeaders : ['Content-Type']
    })
);

app.listen(3000);

app.post('/getData',(req, res)=>{
    res.send('Data received');
});

